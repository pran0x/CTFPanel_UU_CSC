:orphan:

.. This page is retained solely for existing links to /howto/clinic.html.
   Direct readers to the devguide.

**********************
Argument Clinic How-To
**********************


.. note::

   The Argument Clinic How-TO has been moved to the `Python Developer's Guide
   <https://devguide.python.org/development-tools/clinic/>`__.
